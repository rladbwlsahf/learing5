package human07_1;

public class TestExam {

	public static void main(String[] args) {
		Test t = new Test();
		
		t.test("100", "a100");
		System.out.println("시스템 종료");

	}

}
