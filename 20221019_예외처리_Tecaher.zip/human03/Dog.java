package human03;

public class Dog extends Animal{
	public Dog() {
		super();
		System.out.println("Dog 객체 생성");
	}
	public void run() {
		System.out.println("강아지가 뛰어다닙니다.");
	}
}
