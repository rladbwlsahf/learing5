package human03;

public class Cat extends Animal{
	public Cat() {
		super();
		System.out.println("Cat 객체 생성");
	}	
	public void run() {
		System.out.println("고양이가 뛰어다닙니다.");
	}


}
