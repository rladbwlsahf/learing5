package human03;

public class Animal {
	public Animal() {
		System.out.println ("animal 객체 생성");
	}
}
