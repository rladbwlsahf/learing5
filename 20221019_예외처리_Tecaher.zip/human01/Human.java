package human01;

public class Human {
	public String name;
	
	public Human(String name) {
		this.name= name;
	}
	
	public void run() {
		System.out.println("사람이 달리다.");
	}
}
