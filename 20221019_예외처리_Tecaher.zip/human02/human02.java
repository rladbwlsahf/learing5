package human02;

public class human02 {

	public static void main(String[] args) {
		// ArrayIndexOutOfBoundsException..
		
		int[] scores = {10,20,30};
		System.out.printf ("scores[0] = %d \n", scores[0]);
		System.out.printf ("scores[2] = %d \n", scores[2]);
//		System.out.printf ("scores[3] = %d \n", scores[3]);
		

		

	}

}
